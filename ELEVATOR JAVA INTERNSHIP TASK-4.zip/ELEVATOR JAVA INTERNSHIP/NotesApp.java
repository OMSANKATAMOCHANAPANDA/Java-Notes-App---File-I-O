import java.io.*;
import java.util.Scanner;

public class NotesApp {
    private static final String FILE_NAME = "notes.txt";

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        int choice;

        do {
            System.out.println("\n===== Notes App =====");
            System.out.println("1. Write a Note");
            System.out.println("2. View Notes");
            System.out.println("3. Exit");
            System.out.print("Enter your choice: ");
            choice = scanner.nextInt();
            scanner.nextLine(); // consume newline

            switch (choice) {
                case 1 -> writeNote(scanner);
                case 2 -> readNotes();
                case 3 -> System.out.println("Exiting Notes App...");
                default -> System.out.println("Invalid choice. Try again.");
            }
        } while (choice != 3);
    }

    private static void writeNote(Scanner scanner) {
        System.out.print("Enter your note: ");
        String note = scanner.nextLine();

        try (FileWriter fw = new FileWriter(FILE_NAME, true)) {
            fw.write(note + System.lineSeparator());
            System.out.println("Note saved successfully!");
        } catch (IOException e) {
            System.out.println("Error writing to file: " + e.getMessage());
        }
    }

    private static void readNotes() {
        try (BufferedReader br = new BufferedReader(new FileReader(FILE_NAME))) {
            String line;
            System.out.println("\n--- Your Notes ---");
            while ((line = br.readLine()) != null) {
                System.out.println("- " + line);
            }
        } catch (FileNotFoundException e) {
            System.out.println("No notes found yet. Add some!");
        } catch (IOException e) {
            System.out.println("Error reading the file: " + e.getMessage());
        }
    }
}


/*
output:-
=========
Microsoft Windows [Version 10.0.26100.4484]
(c) Microsoft Corporation. All rights reserved.

D:\ELEVATOR JAVA INTERNSHIP>javac NotesApp.java

D:\ELEVATOR JAVA INTERNSHIP>java NotesApp

===== Notes App =====
1. Write a Note
2. View Notes
3. Exit
Enter your choice: 1
Enter your note: Rath Yatra, also known as the Chariot Festival, is a major Hindu 
festival, particularly prominent in Puri, Odisha, India. It commemorates the annual 
journey of the deities Lord Jagannath, his brother Balabhadra, and sister Subhadra, 
from their temple to the Gundicha Temple. This procession involves pulling three 
massive, elaborately decorated wooden chariots through the streets, allowing devotees 
to witness and participate in the deities' journey. The festival is a celebration of 
unity, devotion, and the divine love of the deities.
Note saved successfully!

===== Notes App =====
1. Write a Note
2. View Notes
3. Exit
Enter your choice: 1
Enter your note: Vrindavan is a sacred city in India, renowned for its deep connection 
with Lord Krishna and its status as a major pilgrimage site for Hindus. It's believed 
to be the place where Krishna spent his childhood and performed various divine acts. 
The city is known for its numerous temples, spiritual atmosphere, and vibrant festivals 
like Holi and Janmashtami.
Note saved successfully!

===== Notes App =====
1. Write a Note
2. View Notes
3. Exit
Enter your choice: 1
Enter your note: The Dwarkadhish Temple, also known as Jagat Mandir, is a revered Hindu 
temple dedicated to Lord Krishna, located in Dwarka, Gujarat. It is believed to have 
been originally built by Lord Krishna's great-grandson, Vajranabha, over Krishna's 
residence. The temple has been destroyed and rebuilt multiple times throughout history, 
with the current structure dating back to the 16th century.
Note saved successfully!

===== Notes App =====
1. Write a Note
2. View Notes
3. Exit
Enter your choice: 2

--- Your Notes ---
- Rath Yatra, also known as the Chariot Festival, is a major Hindu festival, particularly 
prominent in Puri, Odisha, India. It commemorates the annual journey of the deities 
Lord Jagannath, his brother Balabhadra, and sister Subhadra, from their temple to the 
Gundicha Temple. This procession involves pulling three massive, elaborately decorated 
wooden chariots through the streets, allowing devotees to witness and participate in 
the deities' journey. The festival is a celebration of unity, devotion, and the divine 
love of the deities.
- Vrindavan is a sacred city in India, renowned for its deep connection with Lord Krishna 
and its status as a major pilgrimage site for Hindus. It's believed to be the place 
where Krishna spent his childhood and performed various divine acts. The city is known 
for its numerous temples, spiritual atmosphere, and vibrant festivals like Holi and 
Janmashtami.
- The Dwarkadhish Temple, also known as Jagat Mandir, is a revered Hindu temple dedicated 
to Lord Krishna, located in Dwarka, Gujarat. It is believed to have been originally 
built by Lord Krishna's great-grandson, Vajranabha, over Krishna's residence. The 
temple has been destroyed and rebuilt multiple times throughout history, with the 
current structure dating back to the 16th century.

===== Notes App =====
1. Write a Note
2. View Notes
3. Exit
Enter your choice: 3
Exiting Notes App...
*/
